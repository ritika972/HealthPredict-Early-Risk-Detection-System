from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import joblib
import pandas as pd
import numpy as np
from src.data_preprocessing import DataPreprocessor

class HealthPredictor:
    def __init__(self):
        self.preprocessor = DataPreprocessor()
        self.models = {}
        self.best_model = None
    
    def train_models(self):
        """Train multiple models and select best"""
        # Load and preprocess data
        df = self.preprocessor.load_data()
        X_train, X_test, y_train, y_test, feature_cols = self.preprocessor.preprocess(df)
        
        # Train models
        models = {
            'LogisticRegression': LogisticRegression(random_state=42),
            'DecisionTree': DecisionTreeClassifier(random_state=42),
            'RandomForest': RandomForestClassifier(n_estimators=100, random_state=42)
        }
        
        results = {}
        for name, model in models.items():
            model.fit(X_train, y_train)
            y_pred = model.predict(X_test)
            accuracy = accuracy_score(y_test, y_pred)
            results[name] = accuracy
            self.models[name] = model
            print(f"{name} Accuracy: {accuracy:.3f}")
        
        # Select best model
        best_model_name = max(results, key=results.get)
        self.best_model = self.models[best_model_name]
        print(f"Best model: {best_model_name} (Accuracy: {results[best_model_name]:.3f})")
        
        # Save models
        joblib.dump(self.preprocessor, 'models/preprocessor.pkl')
        joblib.dump(self.best_model, 'models/best_model.pkl')
        joblib.dump(self.models, 'models/all_models.pkl')
        
        return results
    
    def predict_risk(self, user_data):
        """Predict risk for new user data"""
        X_user = self.preprocessor.preprocess_user_input(user_data)
        risk_idx = self.best_model.predict([X_user])[0]
        risk_level = self.preprocessor.label_encoders['risk'].inverse_transform([risk_idx])[0]
        probability = self.best_model.predict_proba([X_user]).max()
        
        return risk_level, probability