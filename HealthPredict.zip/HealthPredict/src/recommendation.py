class RecommendationEngine:
    def __init__(self):
        self.recommendations = {
            'Diabetes': {
                'High': [
                    "IMMEDIATE ACTION REQUIRED",
                    "• Start doctor consultation immediately",
                    "• Monitor blood sugar 3x daily",
                    "• Begin low-carb diet (under 100g/day)",
                    "• Daily 30-min walk + strength training",
                    "• Avoid sugary drinks and processed foods"
                ],
                'Medium': [
                    "MODERATE RISK - Act Now",
                    "• Reduce refined carbs by 50%",
                    "• Daily 45-min exercise (brisk walk)",
                    "• Test fasting sugar weekly",
                    "• Increase fiber (30g/day)",
                    "• Schedule doctor checkup"
                ],
                'Low': [
                    "LOW RISK - Maintain Healthy Habits",
                    "• Continue balanced diet",
                    "• Exercise 150min/week",
                    "• Annual health checkups",
                    "• Limit sweets to 1-2x/week"
                ]
            },
            'Hypertension': {
                'High': [
                    "🚨 HYPERTENSION CRISIS",
                    "• Visit doctor/emergency TODAY",
                    "• Reduce salt to <1500mg/day",
                    "• No alcohol, no smoking",
                    "• Daily 30-min meditation",
                    "• Monitor BP 2x daily"
                ],
                'Medium': [
                    "⚠️ ELEVATED BP - Lifestyle Changes Needed",
                    "• Cut salt intake by 50%",
                    "• 30min daily aerobic exercise",
                    "• Practice deep breathing 10min/day",
                    "• Limit alcohol to 1 drink/day",
                    "• Weekly BP monitoring"
                ],
                'Low': [
                    "✅ NORMAL BP - Keep it Up!",
                    "• Maintain DASH diet",
                    "• Regular exercise routine",
                    "• Stress management practices",
                    "• Annual BP screening"
                ]
            }
        }
    
    def get_recommendations(self, disease, risk_level):
        return self.recommendations.get(disease, {}).get(risk_level, ["No recommendations available"])
    
    def calculate_bmi_advice(self, weight_kg, height_m):
        bmi = weight_kg / (height_m ** 2)
        if bmi < 18.5:
            return f"BMI: {bmi:.1f} (Underweight)", "Increase healthy calorie intake"
        elif bmi < 25:
            return f"BMI: {bmi:.1f} (Normal)", "Maintain current weight"
        elif bmi < 30:
            return f"BMI: {bmi:.1f} (Overweight)", "Aim for 5-10% weight loss"
        else:
            return f"BMI: {bmi:.1f} (Obese)", "Consult doctor for weight loss plan"