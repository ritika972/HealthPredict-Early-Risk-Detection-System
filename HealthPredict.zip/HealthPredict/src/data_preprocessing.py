import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
import joblib

class DataPreprocessor:
    def __init__(self):
        self.scaler = StandardScaler()
        self.label_encoders = {}
    
    def load_data(self, diabetes_path='data/diabetes.csv', bp_path='data/blood_pressure.csv'):
        """Load and combine datasets"""
        # PIMA Diabetes dataset
        diabetes_df = pd.read_csv(diabetes_path)
        diabetes_df['Disease'] = 'Diabetes'
        
        # Simulated BP dataset (replace with real data)
        np.random.seed(42)
        n_samples = 500
        bp_df = pd.DataFrame({
            'Age': np.random.randint(20, 80, n_samples),
            'BMI': np.random.uniform(18, 40, n_samples),
            'Glucose': np.random.normal(120, 30, n_samples),
            'BloodPressure': np.random.normal(120, 20, n_samples),
            'Insulin': np.random.normal(80, 30, n_samples),
            'DiabetesPedigreeFunction': np.random.uniform(0.1, 2.0, n_samples),
            'Outcome': np.random.choice([0, 1], n_samples, p=[0.65, 0.35]),
            'Disease': 'Hypertension'
        })
        
        # Combine datasets
        df = pd.concat([diabetes_df, bp_df], ignore_index=True)
        return df
    
    def preprocess(self, df):
        """Clean and prepare data"""
        # Handle missing values
        df = df.fillna(df.median(numeric_only=True))
        
        # Feature engineering
        df['Risk_Score'] = (
            df['Glucose'] * 0.3 + 
            df['BloodPressure'] * 0.25 + 
            df['BMI'] * 0.2 + 
            df['Age'] * 0.15 + 
            df['Insulin'] * 0.1
        )
        
        # Create risk levels
        conditions = [
            (df['Risk_Score'] <= 150),  # Low
            ((df['Risk_Score'] > 150) & (df['Risk_Score'] <= 250)),  # Medium
            (df['Risk_Score'] > 250)    # High
        ]
        choices = ['Low', 'Medium', 'High']
        df['Risk_Level'] = np.select(conditions, choices)
        
        # Prepare features
        feature_cols = ['Age', 'BMI', 'Glucose', 'BloodPressure', 'Insulin', 'Risk_Score']
        X = df[feature_cols]
        y = df['Risk_Level']
        
        # Encode target
        le = LabelEncoder()
        y_encoded = le.fit_transform(y)
        self.label_encoders['risk'] = le
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y_encoded, test_size=0.2, random_state=42, stratify=y_encoded
        )
        
        # Scale features
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        return (X_train_scaled, X_test_scaled, y_train, y_test, feature_cols)
    
    def preprocess_user_input(self, user_data):
        """Preprocess single user input"""
        feature_cols = ['Age', 'BMI', 'Glucose', 'BloodPressure', 'Insulin']
        
        # Calculate risk score
        risk_score = (
            user_data['Glucose'] * 0.3 + 
            user_data['BloodPressure'] * 0.25 + 
            user_data['BMI'] * 0.2 + 
            user_data['Age'] * 0.15 + 
            user_data['Insulin'] * 0.1
        )
        
        user_df = pd.DataFrame([user_data])
        user_df['Risk_Score'] = risk_score
        
        X_user = user_df[feature_cols + ['Risk_Score']]
        X_user_scaled = self.scaler.transform(X_user)
        
        return X_user_scaled[0]