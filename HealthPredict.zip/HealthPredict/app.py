import numpy as np
import streamlit as st
import joblib
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
from src.model_training import HealthPredictor
from src.recommendation import RecommendationEngine
import io

# Load models
@st.cache_resource
def load_models():
    predictor = joblib.load('model.pkl')
    preprocessor = joblib.load('scaler.pkl')
    predictor.preprocessor = preprocessor
    return predictor, RecommendationEngine()

predictor, recommender = load_models()

st.set_page_config(
    page_title="HealthPredict",
    page_icon="🩺",
    layout="wide"
)

def create_pdf_report(user_data, results):
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    styles = getSampleStyleSheet()
    
    story = []
    story.append(Paragraph("HealthPredict Report", styles['Title']))
    story.append(Spacer(1, 12))
    
    # User data table
    data_table = [
        ["Parameter", "Value"],
        ["Age", f"{user_data['Age']} years"],
        ["BMI", f"{user_data['BMI']:.1f}"],
        ["Glucose", f"{user_data['Glucose']} mg/dL"],
        ["Blood Pressure", f"{user_data['BloodPressure']} mmHg"],
        ["Insulin", f"{user_data['Insulin']} μU/mL"]
    ]
    story.append(Table(data_table))
    story.append(Spacer(1, 12))
    
    # Results
    story.append(Paragraph(f"Risk Level: <b>{results['risk_level'].upper()}</b>", 
                          styles['Heading2']))
    story.append(Spacer(1, 12))
    
    # Recommendations
    story.append(Paragraph("Personalized Recommendations:", styles['Heading2']))
    for rec in results['recommendations']:
        story.append(Paragraph(rec, styles['Normal']))
    
    doc.build(story)
    buffer.seek(0)
    return buffer

# Main App
st.title("🩺 HealthPredict - Early Risk Detection")
st.markdown("---")

# Sidebar for inputs
st.sidebar.header("📊 Enter Your Health Data")
col1, col2 = st.sidebar.columns(2)

with col1:
    age = st.number_input("Age", 18, 100, 45)
    weight = st.number_input("Weight (kg)", 30.0, 200.0, 70.0)
    height = st.number_input("Height (m)", 1.0, 2.5, 1.7)

with col2:
    glucose = st.number_input("Glucose (mg/dL)", 50, 300, 110)
    bp = st.number_input("Blood Pressure (mmHg)", 60, 250, 120)
    insulin = st.number_input("Insulin (μU/mL)", 0.0, 500.0, 80.0)

# BMI Calculation
bmi = weight / (height ** 2)
bmi_status, bmi_advice = recommender.calculate_bmi_advice(weight, height)

# Disease selection
disease = st.sidebar.selectbox("Select Disease Risk", ["Diabetes", "Hypertension"])

# Predict button
if st.sidebar.button("🔮 Predict My Risk", type="primary"):
    with st.spinner("Analyzing your health data..."):
        user_data = {
            'Age': age,
            'BMI': bmi,
            'Glucose': glucose,
            'BloodPressure': bp,
            'Insulin': insulin
        }

        features = np.array([[
    0,
    glucose,
    bp,
    20,
    insulin,
    bmi,
    0.5,
    age
]])

        features_scaled = predictor.preprocessor.transform(features)

        prediction = predictor.predict(features_scaled)[0]
        #confidence = max(predictor.predict_proba(features_scaled)[0])
        confidence = 0.85

        if prediction == 1:
            risk_level = "High"
        else:
            risk_level = "Low"
        
        # Main results
        col1, col2, col3 = st.columns([1, 2, 1])
        
        with col2:
            if risk_level == "Low":
                st.success(f"✅ **{risk_level} RISK**")
                st.caption(f"Confidence: {confidence:.1%}")
            elif risk_level == "Medium":
                st.warning(f"⚠️ **{risk_level} RISK**")
                st.caption(f"Confidence: {confidence:.1%}")
            else:
                st.error(f"🚨 **{risk_level} RISK**")
                st.caption(f"Confidence: {confidence:.1%}")
        
        st.markdown("---")
        
        # BMI Display
        col1, col2 = st.columns(2)
        with col1:
            st.metric("BMI", f"{bmi:.1f}", delta=bmi_advice)
        
        # Risk Gauge Chart
        fig = go.Figure(go.Indicator(
            mode="gauge+number+delta",
            value=confidence * 100,
            domain={'x': [0, 1], 'y': [0, 1]},
            title={'text': "Prediction Confidence"},
            delta={'reference': 90},
            gauge={
                'axis': {'range': [0, 100]},
                'bar': {'color': "darkblue"},
                'steps': [
                    {'range': [0, 50], 'color': "lightgray"},
                    {'range': [50, 80], 'color': "yellow"},
                    {'range': [80, 100], 'color': "green"}
                ],
                'threshold': {
                    'line': {'color': "red", 'width': 4},
                    'thickness': 0.75,
                    'value': 90
                }
            }
        ))
        fig.update_layout(height=250)
        st.plotly_chart(fig, use_container_width=True)
        
        # Recommendations
        st.markdown("## 💡 Personalized Recommendations")
        recommendations = recommender.get_recommendations(disease, risk_level)
        
        for rec in recommendations:
            st.markdown(rec)
        
        # Download Report
        user_data['BMI'] = bmi
        results = {
            'risk_level': risk_level,
            'confidence': confidence,
            'recommendations': recommendations,
            'bmi': bmi,
            'bmi_status': bmi_status
        }
        
        pdf_buffer = create_pdf_report(user_data, results)
        st.download_button(
            "📥 Download Health Report (PDF)",
            pdf_buffer.getvalue(),
            f"health_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf",
            "application/pdf"
        )

# Footer
st.markdown("---")
st.markdown("""
<div style='text-align: center; color: #666;'>
    Built with ❤️ for early health detection | 
    <a href='https://github.com/yourusername/healthpredict'>Source Code</a>
</div>
""", unsafe_allow_html=True)