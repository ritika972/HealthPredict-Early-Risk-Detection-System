# HealthPredict

## Run
pip install -r requirements.txt

Train model:
python src/model_training.py

Run app:
streamlit run app.py
